package edu.colorado.csci3155.project1


/* -- Here are all the instructions to be supported --*/
sealed trait StackMachineInstruction
case class LoadI(s: String) extends StackMachineInstruction
case class  StoreI(s: String) extends StackMachineInstruction
case class PushI(f: Double) extends StackMachineInstruction
case object AddI extends StackMachineInstruction
case object SubI extends StackMachineInstruction
case object MultI extends StackMachineInstruction
case object DivI extends StackMachineInstruction
case object ExpI extends StackMachineInstruction
case object LogI extends StackMachineInstruction
case object SinI extends StackMachineInstruction
case object CosI extends StackMachineInstruction
case object PopI extends StackMachineInstruction


object StackMachineEmulator {
      /* Function emulateSingleInstruction
            Given a list of doubles to represent a stack
                  a map from string to double precision numbers for the environment
            and   a single instruction of type StackMachineInstruction
            Return a tuple that contains the
                  modified stack that results when the instruction is executed.
                  modified environment that results when the instruction is executed.

            Make sure you handle the error cases: eg., stack size must be appropriate for the instruction
            being executed. Division by zero, log of a non negative number
            Throw an exception or assertion violation when error happens.
      */
      def emulateSingleInstruction(stack: List[Double],
                                    env: Map[String, Double],
                                    ins: StackMachineInstruction): (List[Double], Map[String, Double]) = ins match {
            // TODO: Your code here.
            case LoadI(s) => {
                  if (stack.isEmpty) {
                        throw new RuntimeException("Stack underflow");
                  }
                  else {
                        val v = stack.head;
                        (stack.tail, env + (s -> v));
                  }
            }
            case StoreI(s) => {
                  env.get(s) match {
                        case Some(v) => {
                              (v :: stack, env);
                        }
                        case None => {
                              throw new RuntimeException(s"Identifier $s not found in environment");
                        }
                  }
            }
            case PushI(d) => {
                  (d :: stack, env);
            }
            case AddI => {
                  if (stack.size < 2) {
                        throw new RuntimeException("Stack underflow");
                  }
                  else {
                        val v1 = stack.head;
                        val v2 = stack.tail.head;
                        ((v1 + v2) :: stack.tail.tail, env);
                  }
            }
            case SubI => {
                  if (stack.size < 2) {
                        throw new RuntimeException("Stack underflow");
                  }
                  else {
                        val v1 = stack.head;
                        val v2 = stack.tail.head;
                        ((v2 - v1) :: stack.tail.tail, env);
                  }
            }
            case MultI => {
                  if (stack.size < 2) {
                        throw new RuntimeException("Stack underflow");
                  }
                  else {
                        val v1 = stack.head;
                        val v2 = stack.tail.head;
                        ((v1 * v2) :: stack.tail.tail, env);
                  }
            }
            case DivI => {
                  if (stack.size < 2) {
                        throw new RuntimeException("Stack underflow");
                  }
                  else {
                        val v1 = stack.head;
                        val v2 = stack.tail.head;
                        if (v1 == 0) {
                              throw new RuntimeException("Division by zero");
                        }
                        else {
                              ((v2 / v2) :: stack.tail.tail, env);
                        }
                  }
            }
            case ExpI => {
                  if (stack.isEmpty) {
                        throw new RuntimeException("Stack underflow");
                  }
                  else {
                        val v = stack.head;
                        (Math.exp(v) :: stack.tail, env);
                  }
            }
            case LogI => {
                  if (stack.isEmpty) {
                        throw new RuntimeException("Stack underflow");
                  }
                  else {
                        val v = stack.head;
                        if (v <= 0) {
                              throw new RuntimeException("Log of non-positive number");
                        }
                        else {
                              (Math.log(v) :: stack.tail, env);
                        }
                  }
            }
            case SinI => {
                  if (stack.isEmpty) {
                        throw new RuntimeException("Stack underflow");
                  }
                  else {
                        val v = stack.head;
                        (Math.sin(v) :: stack.tail, env);
                  }
            }
            case CosI => {
                  if (stack.isEmpty) {
                        throw new RuntimeException("Stack underflow");
                  }
                  else {
                        val v = stack.head;
                        (Math.cos(v) :: stack.tail, env);
                  }
            }
            case PopI => {
                  if (stack.isEmpty) {
                        throw new RuntimeException("Stack underflow");
                  }
                  else {
                        (stack.tail, env);
                  }
            }
      }

      /* Function emulateStackMachine
            Execute the list of instructions provided as inputs using the
            emulateSingleInstruction function.
            Use foldLeft over list of instruction rather than a for loop if you can.
            Return value must be the final environment.

            Hint: accumulator for foldLeft must be a tuple (List[Double], Map[String,Double])
                  initial value of this accumulator must be (Nil, Map.empty)
                  You should use emulateSingleInstruction to update the accumulator.
                  It will all fit nicely once you figure it out.
      */
      def emulateStackMachine(instructionList: List[StackMachineInstruction]): Map[String, Double] = {
            // TODO: Your code here.
            val initialStack: List[Double] = Nil
            val initialEnv: Map[String, Double] = Map.empty
            val newEnv = instructionList.foldLeft((initialStack, initialEnv)) {
                  case ((stack, env), instruction) =>
                        emulateSingleInstruction(stack, env, instruction);
            }
            newEnv._2;
      }
}

