#include "functions.hpp"

int fooA(){
    return 7;
}
