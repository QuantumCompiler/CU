#include <iostream>
#include <fstream>

using namespace std;

int main(int argc, char* argv[]){
    cout << "hello penguin\n";
    return 0;
}