#include <iostream>
#include <fstream>

using namespace std;

int main(int argc, char* argv[]){
    return 0;
}