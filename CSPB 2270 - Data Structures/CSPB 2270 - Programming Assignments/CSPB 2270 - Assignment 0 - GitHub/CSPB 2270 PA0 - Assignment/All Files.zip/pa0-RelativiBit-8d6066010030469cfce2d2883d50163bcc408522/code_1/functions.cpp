#include "functions.hpp"

int fooA(){

}
