#include <iostream>
#include "../code/PriorityQueue.h"

using namespace std;

int main(){

    // do your tests on PriorityQueue class here

    return 0;
}
