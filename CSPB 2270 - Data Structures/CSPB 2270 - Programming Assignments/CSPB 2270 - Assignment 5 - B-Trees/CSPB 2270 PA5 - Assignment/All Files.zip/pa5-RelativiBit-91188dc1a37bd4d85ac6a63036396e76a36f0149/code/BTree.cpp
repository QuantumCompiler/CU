#include "BTree.h"

// constructor, initialize class variables and pointers here if need.
BTree::BTree(){
  // Your code here
}

//deconstructor,
BTree::~BTree(){
}

void BTree::insert(shared_ptr<btree> root, int key){

}

void BTree::remove(shared_ptr<btree> root, int key){

}

shared_ptr<btree> BTree::find(shared_ptr<btree> root, int key){
  return shared_ptr<btree>(NULL);
}

int BTree::count_nodes(shared_ptr<btree> root){
  return 0;
}

int BTree::count_keys(shared_ptr<btree> root){
  return 0;
}