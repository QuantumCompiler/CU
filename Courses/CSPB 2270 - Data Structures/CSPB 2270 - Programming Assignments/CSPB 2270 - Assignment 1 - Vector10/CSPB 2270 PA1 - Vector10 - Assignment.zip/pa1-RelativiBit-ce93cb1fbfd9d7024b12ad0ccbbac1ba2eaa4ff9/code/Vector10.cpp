#include "Vector10.h"

Vector10::Vector10(){
    // YOUR CODE HERE
}

Vector10::~Vector10(){
    // You don't need to add anything here
}

// Implement this function first, since all tests use it.
int Vector10::ValueAt(int index){
    // YOUR CODE HERE
}

// Implement this function second, since most tests use it.
bool Vector10::PushBack(int value){
    // YOUR CODE HERE
}

int Vector10::CountEmpty(){
    // YOUR CODE HERE
}

bool Vector10::Search(int value){
    // YOUR CODE HERE
}

bool Vector10::Remove(int index){
    // YOUR CODE HERE
}