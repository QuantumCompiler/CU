#include <iostream>
#include "../code/BST.h"

using namespace std;

int main(){

    // Do some printing
    int var;
    cout << "Hello World, please enter a number " << endl;
    cin >> var;
    cout << "your number was : " << var << endl;


    return 0;
}
