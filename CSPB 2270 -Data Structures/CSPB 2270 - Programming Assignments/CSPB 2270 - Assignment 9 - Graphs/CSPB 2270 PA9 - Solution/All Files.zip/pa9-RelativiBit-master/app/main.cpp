#include <iostream>
#include "../code/Graph.h"
#include "../code/Node.h"
#include "../code/Edge.h"

using namespace std;

int main(){

    // Do some printing
    int var;
    cout << "Hello World, please enter a number " << endl;
    cin >> var;
    cout << "your number was : " << var << endl;


    return 0;
}
